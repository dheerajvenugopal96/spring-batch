package com.infybuzz.config;

import java.io.IOException;
import java.io.Writer;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileFooterCallback;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.json.JacksonJsonObjectMarshaller;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonFileItemWriter;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import com.infybuzz.model.StudentCsv;
import com.infybuzz.model.StudentDB;
import com.infybuzz.model.StudentJson;
import com.infybuzz.processor.FirstItemProcessor;
import com.infybuzz.reader.FirstItemReader;
import com.infybuzz.writer.FirstItemWriter;

@Configuration
public class SampleJob {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private FirstItemReader firstItemReader;
	
	@Autowired
	private FirstItemProcessor firstItemProcessor;
	
	@Autowired
	private FirstItemWriter firstItemWriter;

	@Autowired
	private DataSource dataSource;

	@Bean
	public Job chunkJob() {
		return jobBuilderFactory.get("Chunk Job")
				.incrementer(new RunIdIncrementer())
				.start(firstChunkStep())
				.build();
	}
	
	private Step firstChunkStep() {
		return stepBuilderFactory.get("First Chunk Step")
//				.<StudentCsv, StudentCsv>chunk(3)
				.<StudentCsv, StudentCsv>chunk(3).reader(flatFileItemReader(null))
//				.reader(jsonItemReader(null))
//				.reader(jdbcCursorItemReader())
//				.processor(firstItemProcessor)
//				.writer(firstItemWriter)
//				.writer(flatFileItemWriter(null))
//				.writer(jsonFileItemWriter(null))
				.writer(jdbcBatchItemWriter1())
				.build();
	}

	@StepScope
	@Bean
	public FlatFileItemReader<StudentCsv> flatFileItemReader(
			@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {
		FlatFileItemReader<StudentCsv> flatFileItemReader = new FlatFileItemReader<>();
		flatFileItemReader.setResource(fileSystemResource);
		/*
		 * flatFileItemReader.setLineMapper(new DefaultLineMapper<StudentCsv>() { {
		 * setLineTokenizer(new DelimitedLineTokenizer() { { setNames("ID",
		 * "First Name", "Last Name", "Email"); } });
		 * 
		 * setFieldSetMapper(new BeanWrapperFieldSetMapper<StudentCsv>() { {
		 * setTargetType(StudentCsv.class); } });
		 * 
		 * } });
		 */

		DefaultLineMapper<StudentCsv> defaultLineMapper = new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setNames("ID", "First Name", "Last Name", "Email");

		BeanWrapperFieldSetMapper<StudentCsv> beanWrapper = new BeanWrapperFieldSetMapper<>();
		beanWrapper.setTargetType(StudentCsv.class);

		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(beanWrapper);

		flatFileItemReader.setLineMapper(defaultLineMapper);
		flatFileItemReader.setLinesToSkip(1);
		return flatFileItemReader;
	}

	@StepScope
	@Bean
	public JsonItemReader<StudentJson> jsonItemReader(
			@Value("#{jobParameters['inputFile']}") FileSystemResource fileSystemResource) {

		JsonItemReader<StudentJson> jsonItemReader = new JsonItemReader<>();
		jsonItemReader.setResource(fileSystemResource);
		jsonItemReader.setJsonObjectReader(new JacksonJsonObjectReader<>(StudentJson.class));

		jsonItemReader.setMaxItemCount(8);
		jsonItemReader.setCurrentItemCount(2);

		return jsonItemReader;
	}

	public JdbcCursorItemReader<StudentDB> jdbcCursorItemReader() {

		JdbcCursorItemReader<StudentDB> jdbcCursorItemReader = new JdbcCursorItemReader<>();

		jdbcCursorItemReader.setDataSource(dataSource);
		jdbcCursorItemReader
				.setSql("select id,first_name as firstName, last_name as lastName,email from student");
		jdbcCursorItemReader.setRowMapper(new BeanPropertyRowMapper<StudentDB>() {
			{
				setMappedClass(StudentDB.class);
			}
		});

		return jdbcCursorItemReader;
	}

	@Bean
	@StepScope
	public FlatFileItemWriter<StudentDB> flatFileItemWriter(
			@Value("#{jobParameters['outputFile']}") FileSystemResource fileSystemResource) {

		FlatFileItemWriter<StudentDB> flatFileItemWriter = new FlatFileItemWriter<>();

		flatFileItemWriter.setResource(fileSystemResource);
		flatFileItemWriter.setHeaderCallback(new FlatFileHeaderCallback() {

			@Override
			public void writeHeader(Writer writer) throws IOException {
				writer.write("ID,First Name,Last Name,Email");

			}
		});

		DelimitedLineAggregator<StudentDB> lineAggregator = new DelimitedLineAggregator<>();

		BeanWrapperFieldExtractor<StudentDB> fieldExtractor = new BeanWrapperFieldExtractor<>();
		fieldExtractor.setNames(new String[] { "id", "firstName", "lastName", "email" });

		lineAggregator.setFieldExtractor(fieldExtractor);

		flatFileItemWriter.setLineAggregator(lineAggregator);

		flatFileItemWriter.setFooterCallback(new FlatFileFooterCallback() {

			@Override
			public void writeFooter(Writer writer) throws IOException {
				writer.write("Created at : " + new Date());

			}
		});
		return flatFileItemWriter;
	}

	@Bean
	@StepScope
	public JsonFileItemWriter<StudentJson> jsonFileItemWriter(
			@Value("#{jobParameters['outputFile']}") FileSystemResource fileSystemResource) {

		JsonFileItemWriter<StudentJson> jsonFileItemWriter = new JsonFileItemWriter<>(fileSystemResource,
				new JacksonJsonObjectMarshaller<StudentJson>());

		return jsonFileItemWriter;

	}

	@Bean
	public JdbcBatchItemWriter<StudentCsv> jdbcBatchItemWriter() {

		JdbcBatchItemWriter<StudentCsv> jdbcBatchItemWriter = new JdbcBatchItemWriter<>();

		jdbcBatchItemWriter.setDataSource(dataSource);
		jdbcBatchItemWriter
				.setSql("insert into student(id,first_name,last_name,email) values (:id,:firstName,:lastName,:email)");
		jdbcBatchItemWriter
				.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<StudentCsv>());

		return jdbcBatchItemWriter;
	}

	@Bean
	public JdbcBatchItemWriter<StudentCsv> jdbcBatchItemWriter1() {

		JdbcBatchItemWriter<StudentCsv> jdbcBatchItemWriter = new JdbcBatchItemWriter<>();

		jdbcBatchItemWriter.setDataSource(dataSource);
		jdbcBatchItemWriter.setSql("insert into student(id,first_name,last_name,email) values (?,?,?,?)");
		jdbcBatchItemWriter.setItemPreparedStatementSetter(new ItemPreparedStatementSetter<StudentCsv>() {

			@Override
			public void setValues(StudentCsv item, PreparedStatement ps) throws SQLException {
				ps.setLong(1, item.getId());
				ps.setString(2, item.getFirstName());
				ps.setString(3, item.getLastName());
				ps.setString(4, item.getEmail());

			}
		});

		return jdbcBatchItemWriter;
	}

}
