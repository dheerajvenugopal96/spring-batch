package com.infybuzz.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.infybuzz.model.StudentDB;
import com.infybuzz.model.StudentJson;

@Component
public class FirstItemProcessor implements ItemProcessor<StudentDB, StudentJson> {

	@Override
	public StudentJson process(StudentDB item) throws Exception {
		System.out.println("Inside Item Processor");
		StudentJson json = new StudentJson();
		json.setId(item.getId());
		json.setFirstName(item.getFirstName());
		json.setLastName(item.getLastName());
		json.setEmail(item.getEmail());
		return json;
	}

}
